import 'package:flutter/material.dart';

class SampleListView extends StatelessWidget {
  const SampleListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Belajal ListView'),
      ),
      body: ListView(
        children: [
          Container(
            height: 50,
            color: Colors.amber[900],
          ),
          Container(
            height: 50,
            color: Colors.amber[800],
          ),
          Container(
            height: 50,
            color: Colors.amber[700],
          ),
          Container(
            height: 50,
            color: Colors.amber[600],
          ),
          Container(
            height: 50,
            color: Colors.amber[500],
          ),
          Container(
            height: 50,
            color: Colors.amber[400],
          ),
          Container(
            height: 50,
            color: Colors.amber[300],
          ),
        ],
      ),
    );
  }
}
